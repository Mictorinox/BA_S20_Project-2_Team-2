# BA_S20_Project-2_Team-2
Team project 2 for Business Analysis course in summer 2020
